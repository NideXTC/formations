<?php

// login : toto
// password : tata

echo 'toto';